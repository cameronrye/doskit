Solstice By Valhalla                                      Released 15-11-1995
--------------------                                      -------------------

Machine requirements :
----------------------
486, 486DX2+ recommended
4Mb of ram (may require clean boot)
Fairly fast VGA video card recommended
Unfortunately the demo does not run under Windows 95, this is a problem with
the music player, when I get a working update of the music player, I will 
release the updated .EXE to work under win95.

Command line switches :
-----------------------

SOLSTICE rgbfix - will fix the 'banding' which may appear in the hi-color
RGB effects, this will slow down the frame rate, but should give a perfect
picture.

Notes on use :
--------------
Solstice is public domain, this means that you can freely give the
COMPLETE version of this demo to any of your friends etc. as long as no
charge is made.
PD and Shareware distributors may distribute this demo as long it is the
complete version, and as long as there are no special pricing policies on
this product.
Any other commercial establishments using this product must contact us before
use. This also includes CDRom distrubution, if you wish to put this on your
CDRom, you MUST contact us first!
This program has been thoroughly tested, and should cause no problems, you use
this software at your own risk. If any bugs are found, we will attempt to 
rectify them.

Detailed Credits :
------------------
All Code : Sandman
All Music : Big Jim
Backdrops & texture maps : Sandman
Objects : Sandman (Starfish by Dambuster)
Valhalla/Presents pictures : Sandman
Solstice picture : Vision FX
Bar Scene : Dambuster
Design & ideas : Sandman, Big Jim, Hollywood, Dambuster, Vision FX


Thanks to :
-----------
Guru and Alfred for Midas - Let everyone hear that music :)
Tran & Daredevil for PMODEW - nice to see a cool demo using your code ? :)
The Author of GURUMODE - nice to have a SAFE X Mode library.
Moebius & Alpha for the use of their computers at Wired 95.
Farnar / Nostalgia for doing the 5 minute logo at the party.
The Organisers of wired 95 for organising such a cool party with no power cuts
Implode for doing that 1 line of code :)

Greetings to :
--------------
Every cool group in the scene, keep up the cool work guys !
All the guys at Sales Curve, hope ya like the demo :)
Everyone at Hybrid ... See ya at christmas !

And a special mention to Big Jim for saying "Well Pete, I don't think we're 
gonna win this one" 2 days before the party :)

Relapse over ...... Back to rock the scene again .......
Sandman / Valhalla.
