
                           THE OFFICIAL VOTING FORM

                                      of

                          FUTURE CREW'S DISKMAGAZINE


                 -=>)]   T H E   W O R L D C H A R T S   [(<=-

-------------------------------------------------------------------------------

        Fill this textfile out and send it back to us and you will find your
name in the Voters List in the next issue of our diskmag. And remember, you
will have to fill at least 5 entries on the demo and group charts and 3 entries
on the coders, musicians and graphics men, otherwise your vote will not be used
and you will not be in the Voters List. By doing this we are trying to avoid
getting only a huge pile of crap votes. So, please, take your time and try to
fill out the entries as well as you can. And since this is the PC scene we are
at, do not vote for any Amiga/Atari ST/C-64/other people or stuff, only PC.

You have several ways to send in your vote:

Via FAX:        +358-0-420 8620, GORE / FC

By mail:        GORE / Future Crew
                Hiiralantie 27 A
                02160 Espoo, FINLAND

To our WHQ:     Starport - FC WHQ BBS
                Node 1: +358-0-8044626, HST/V32b
                Node 2: +358-0-8041133, V22b/MNP 5
                SysOp:  Abyss / FC

Via E-mail:     jtheinon@kruuna.helsinki.fi

-------------------------------------------------------------------------------
Your handle or real name :
Your job description     :
Group or company         :
City and country         :
Date answered            :
-------------------------------------------------------------------------------
                         TOP 10 demos:
                         *************

 Demo name:                                     Group:
 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
                         TOP 10 groups:
                         **************

 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
                         TOP 10 coders:
                         **************

 Coder's name:                                  Group:
 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
                         TOP 10 musicians:
                         *****************

 Musician's name:                               Group:
 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
                         TOP 10 graphics artists:
                         ************************

 Graphician's name:                             Group:
 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
                         TOP 10 games:
                         *************

 Game:                                          Publisher and/or author:
 1.
 2.
 3.
 4.
 5.
 6.
 7.
 8.
 9.
10.
-------------------------------------------------------------------------------
��������� �      � ��������� �������� �      �     �       �  �������� �      �
    �     �������� ��������� �      � ��������     ���������  �      � �      �
    �     �      � �       � �      � �    ���         �      �      � �      �
    �     �      � �       � �      � �      �         �      �������� ��������

���������  F O R   Y O U R   C O - O P E R A T I O N  ��������������GORE/FC۲��
-------------------------------------------------------------------------------
