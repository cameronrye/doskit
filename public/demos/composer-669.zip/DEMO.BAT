composd /fhardwire /p /s\composd\669

