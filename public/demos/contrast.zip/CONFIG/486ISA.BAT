contrast -w1 
