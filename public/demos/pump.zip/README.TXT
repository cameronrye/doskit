                                  �P�U�M�P�

                                        An Iguana production in 1995.
                                        First place at the Euskal Party.
                                        This is the real release version.

��������������������������----��� � �    � � ���----������������������������Ĵ

        - For regular information, read PUMP.NFO

��������������������������----��� � �    � � ���----������������������������Ĵ

        - Installation:

  The demo should need no install procedure; if you're reading this text
then you have already unzipped it, so simply type "PUMP" to run it.

  There should be no problem running the demo directly from a CD-ROM, but
we haven't got a CD writer to try, so we will have to trust our skills on
that one. Perhaps from a CD there will be synchronization problems due to
long load times, but I don't foresee much more than a couple black screens.

  In order to run the demo, the setup program writes a file in the C drive,
named C:\PUMP.VTO. This is the script file that links together the DemoVT
music system and the demo itself. On exit, the file is deleted again so no
trash is left behind Pump. If you're curious about it, UNDELETE it and see.

  Soundblaster support will require more memory than Gravis Ultrasound or
No Sound, but EMS is OK for that. Again, we haven't made extensive checks
about the amount of memory that you need, or the optimal configuration; I
think most current systems will be OK without even having to reboot.

  The demo has been tested to run in DOS sessions under Win 3.1 and Win'95.
In fact, some of the party-coding was done under Win'95. It doesn't use any
weird display modes, so it is OK to run it in windowed mode. However, the
best results will be got in plain DOS mode. Running under GUI environments
is detected by searching for the "windir" environment variable, in case you
want to experiment. The possible problems include sound crashes depending
on your soundcard and driver versions, and usually the color flashes won't
be as elegant as in plain DOS mode.

  No tests have been made under OS/2, but all of the above should apply.

  Note that we don't have a special interest that the demo be run in such
environments; but somehow we feel that getting them OK is a proof of the
stability of the code.

  The demo hasn't been tried on a 386 machine. Even if it runs (I dunno why
wouldn't it, perhaps for the FPU?) things will be slow as hell, and the
show will be quite poor. The golden face has more than 3000 environment-
mapped polygons, and I think that one's too much for a good ole 386.

��������������������������----��� � �    � � ���----������������������������Ĵ

        - Troubleshooting

  + The demo doesn't run, what can I do?
        Please, try to be more specific or we won't be able to help.

  + I run the demo and the computer hangs.
        I have no idea. Try with the cleanest configuration of the
        machine (press F5 at startup if you have MS-DOS 6 or above), or
        else with the most complex. Experiment with memory managers and
        other TSRs. Also try running the demo without sound (see below).

  + The demo aborts an error with a word like "Alloc".
        You need more memory free. About 2.5 megs should do.

  + The demo aborts with something about source file and line.
        The demo files have been corrupted somehow. Get a good archive of
        the demo. If the problem persists, check your system against
        viruses.

  + I am running Pump under Windows or OS/2 and it goes jumpy and slow.
        Make sure your DOS session has the "windir" variable set. It doesn't
        matter what it contains, so just type "SET WINDIR=KK".

  + I hear no sound, or the demo hangs.
        If with the "No Sound" option everything goes OK, then check the
        setting of your card and set them correctly for the demo.

  + I don't have a soundcard, and the "No Sound" option doesn't work.
        Try setting different COM settings under the "Choose Port" option.
        If the problem persists, try booting the machine without loading
        the mouse driver. The music systems uses a serial port to get the
        timing when there is no soundcard installed, so choose a port with
        a serial chip installed on it.

  + The demo doesn't run no matter what boot and settings I try.
        Perhaps there is some incompatibility between your machine and the
        protected-mode DOS extender. There may be no solution for this,
        except going to a friend's and watching the demo there.

  + The demo run slow and jerky on my computer.
        Perhaps your computer is not powerful enough, or the CMOS setup is
        not properly configured. Note: CHANGING THE CMOS SETUP NEEDS DEEP
        KNOWLEDGE AND CAN RESULT IN DAMAGE. It's up to you to take the
        risk, but I can tell you that my 486/66 can beat a lot of 486/80's
        and some 486/100s by properly configuring wait states and such. On
        most computers the settings are quite conservative. Also, the video
        card is very important: it should be local bus (PCI or VESA), and
        should be a true 32-bit card (unlike most S3 found in motherboards).
        My system (where the demo runs quite smoothly) is a 486/66 with a
        nice CMOS setup, a Gravis Ultrasound Max and a ET4000/w32p VLB SVGA.
        Anyway, different effects make different use of system parts, so some
        will be very sensitive to the VGA while others can double or triple
        the speed with 0 DRAM read waitstates. PCs are so complex...

��������������������������----��� � �    � � ���----������������������������Ĵ

                                        Madrid, October 26th of 1995.
